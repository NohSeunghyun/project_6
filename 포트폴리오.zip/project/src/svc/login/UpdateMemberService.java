package svc.login;

import static db.JdbcUtil.*;

import java.sql.Connection;

import dao.AdminDAO;
import dao.LoginDAO;
import vo.login.AdminMemberBean;
import vo.login.CompanyGroupMemberBean;
import vo.login.NormalMemberBean;

public class UpdateMemberService {

	//일반회원 개인정보 수정 Service
	public boolean updateNormalMember(NormalMemberBean normalMemberUpdate) {
		boolean isUpdateSuccess = false;
		int updateCount = 0;
		Connection con = null;
		try {
			con = getConnection();
			LoginDAO loginDAO = LoginDAO.getInstance();
			loginDAO.setConnection(con);
	
			updateCount = loginDAO.isupdateNormalMember(normalMemberUpdate);
			
			if (updateCount > 0) {
				commit(con);
				isUpdateSuccess = true;
			} else {
				rollback(con);
			}
		} catch (Exception e) {
			System.out.println("updateNormalMemberService 에러" + e);
		} finally {
			close(con);
		}
		return isUpdateSuccess;
	}

	//기업/단체회원 개인정보 수정 Service
	public boolean updateComgrpMember(CompanyGroupMemberBean companyGroupMemberBean) {
		boolean isUpdateSuccess = false;
		int updateCount = 0;
		Connection con = null;
		try {
			con = getConnection();
			LoginDAO loginDAO = LoginDAO.getInstance();
			loginDAO.setConnection(con);
	
			updateCount = loginDAO.isupdateComgrpMember(companyGroupMemberBean);
			
			if (updateCount > 0) {
				commit(con);
				isUpdateSuccess = true;
			} else {
				rollback(con);
			}
		} catch (Exception e) {
			System.out.println("updateComgrpMemberService 에러" + e);
		} finally {
			close(con);
		}
		return isUpdateSuccess;
	}

	//관리자 개인정보 수정 Service
	public boolean updateAdminMember(AdminMemberBean adminMemberBean) {
		boolean isUpdateSuccess = false;
		int updateCount = 0;
		Connection con = null;
		try {
			con = getConnection();
			AdminDAO adminDAO = AdminDAO.getInstance();
			adminDAO.setConnection(con);
	
			updateCount = adminDAO.isupdateAdminMember(adminMemberBean);
			
			if (updateCount > 0) {
				commit(con);
				isUpdateSuccess = true;
			} else {
				rollback(con);
			}
		} catch (Exception e) {
			System.out.println("updateAdminMemberService 에러" + e);
		} finally {
			close(con);
		}
		return isUpdateSuccess;
	}

}
