package svc.campaign;

import static db.JdbcUtil.*;

import java.sql.Connection;

import dao.CampaignDAO;
import vo.campaign.CampaignBean;

public class CampaignUpdateService {

	//캠페인 수정(사진) Service
	public boolean campaignUpdateChangeImage(CampaignBean campaignBean) {
		boolean isCampaignUpdateSuccess = false;
		Connection con = null;
		try {
			con = getConnection();
			CampaignDAO campaignDAO = CampaignDAO.getInstance();
			campaignDAO.setConnection(con);
			
			int updateCount = campaignDAO.campaignUpdateChangeImage(campaignBean);
			
			if (updateCount > 0) {
				commit(con);
				isCampaignUpdateSuccess = true;
			} else {
				rollback(con);
			}
		} catch (Exception e) {
			System.out.println("campaignUpdateIncludeFileService 에러" + e);
		} finally {
			close(con);
		}
		return isCampaignUpdateSuccess;
	}

	//캠페인 수정(제목, 내용) Service
	public boolean campaignUpdate(String campaign_name, String campaign_content, int campaign_no) {
		boolean isCampaignUpdateSuccess = false;
		Connection con = null;
		try {
			con = getConnection();
			CampaignDAO campaignDAO = CampaignDAO.getInstance();
			campaignDAO.setConnection(con);
			
			int updateCount = campaignDAO.campaignUpdate(campaign_name, campaign_content, campaign_no);
			
			if (updateCount > 0) {
				commit(con);
				isCampaignUpdateSuccess = true;
			} else {
				rollback(con);
			}
		} catch (Exception e) {
			System.out.println("campaignUpdateService 에러" + e);
		} finally {
			close(con);
		}
		return isCampaignUpdateSuccess;
	}

}
