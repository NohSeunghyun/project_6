package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import action.Action;
import action.login.ChangePwProAction;
import action.login.EmailSearchIDProAction;
import action.login.IdOverlapCheckProAction;
import action.login.JoinMemberShip_ComgrpProAction;
import action.login.JoinMemberShip_NormalProAction;
import action.login.LoginProAction;
import action.login.LogoutProAction;
import action.login.PersonalInformationProAction;
import action.login.PhoneSearchIDProAction;
import action.login.SearchPWProAction;
import action.login.UpdateComgrpMemberProAction;
import action.login.UpdateNormalMemberProAction;
import action.login.ChangePw2ProAction;
import action.login.DeleteMemberProAction;
import vo.ActionForward;

/**
 * Servlet implementation class LoginController
 */
@WebServlet("*.login")
public class LoginFrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginFrontController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doProcess(request, response);
	}
	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doProcess(request, response);
	}
	
	private void doProcess(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		String requestURI = request.getRequestURI();
		String contextPath = request.getContextPath();
		String command = requestURI.substring(contextPath.length());
		Action action = null;
		ActionForward forward = null;
		if (command.equals("/loginPro.login")) {//로그인 처리
			action = new LoginProAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if (command.equals("/idOverlapCheck.login")) {//아이디 중복 체크 처리
			action = new IdOverlapCheckProAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if (command.equals("/joinMemberShip_normal.login")) {//일반회원 회원가입 처리
			action = new JoinMemberShip_NormalProAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if (command.equals("/joinMemberShip_comgrp.login")) {//기업/단체회원 회원가입 처리
			action = new JoinMemberShip_ComgrpProAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if (command.equals("/phoneSearchID.login")) {//핸드폰번호로 아이디 찾기 처리
			action = new PhoneSearchIDProAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if (command.equals("/emailSearchID.login")) {//이메일주소로 아이디 찾기 처리
			action = new EmailSearchIDProAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if (command.equals("/searchPW.login")) {//비밀번호 찾기 처리
			action = new SearchPWProAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if (command.equals("/changePw2.login")) {//비밀번호 찾기 후 비밀번호 변경 처리
			action = new ChangePw2ProAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if (command.equals("/personalInformation.login")) {//개인정보 조회 처리
			action = new PersonalInformationProAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if (command.equals("/changePw.login")) {//개인정보 비밀번호 변경 처리
			action = new ChangePwProAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if (command.equals("/deleteMember.login")) {//회원탈퇴 처리
			action = new DeleteMemberProAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if (command.equals("/updateNormalMember.login")) {//일반회원 개인정보 수정 처리
			action = new UpdateNormalMemberProAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if (command.equals("/updateComgrpMember.login")) {//기업/단체회원 개인정보 수정 처리
			action = new UpdateComgrpMemberProAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if (command.equals("/logout.login")) {//로그아웃 처리
			action = new LogoutProAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		/******************************포워딩******************************/
		
		if(forward != null) {
			if(forward.isRedirect()) {
				response.sendRedirect(forward.getPath());
			} else {
			request.getRequestDispatcher(forward.getPath()).forward(request, response);
			}
		}
	}
}


