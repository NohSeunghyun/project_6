package vo.login;

import java.sql.Date;

public class NormalMemberBean {
	private String normal_member_id;
	private String normal_member_pw;
	private String normal_member_name;
	private String normal_member_birth;
	private String normal_member_phone;
	private String normal_member_gender;
	private String normal_member_email;
	private Date normal_member_date;
	private String normal_member_grade;
	
	public String getNormal_member_id() {
		return normal_member_id;
	}

	public void setNormal_member_id(String normal_member_id) {
		this.normal_member_id = normal_member_id;
	}

	public String getNormal_member_pw() {
		return normal_member_pw;
	}

	public void setNormal_member_pw(String normal_member_pw) {
		this.normal_member_pw = normal_member_pw;
	}

	public String getNormal_member_name() {
		return normal_member_name;
	}

	public void setNormal_member_name(String normal_member_name) {
		this.normal_member_name = normal_member_name;
	}
	

	public String getNormal_member_birth() {
		return normal_member_birth;
	}

	public void setNormal_member_birth(String normal_member_birth) {
		this.normal_member_birth = normal_member_birth;
	}

	public String getNormal_member_phone() {
		return normal_member_phone;
	}

	public void setNormal_member_phone(String normal_member_phone) {
		this.normal_member_phone = normal_member_phone;
	}

	public String getNormal_member_gender() {
		return normal_member_gender;
	}

	public void setNormal_member_gender(String normal_member_gender) {
		this.normal_member_gender = normal_member_gender;
	}

	public String getNormal_member_email() {
		return normal_member_email;
	}

	public void setNormal_member_email(String normal_member_email) {
		this.normal_member_email = normal_member_email;
	}

	public Date getNormal_member_date() {
		return normal_member_date;
	}

	public void setNormal_member_date(Date normal_member_date) {
		this.normal_member_date = normal_member_date;
	}

	public String getNormal_member_grade() {
		return normal_member_grade;
	}

	public void setNormal_member_grade(String normal_member_grade) {
		this.normal_member_grade = normal_member_grade;
	}
	
}