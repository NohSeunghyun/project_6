package action.login;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import action.Action;
import svc.login.JoinMembership_NormalProService;
import vo.ActionForward;
import vo.login.NormalMemberBean;

public class JoinMemberShip_NormalProAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = null;
		
		NormalMemberBean normalMember = new NormalMemberBean();

		normalMember.setNormal_member_id(request.getParameter("normal_member_id"));
		normalMember.setNormal_member_pw(request.getParameter("normal_member_pw"));
		normalMember.setNormal_member_name(request.getParameter("normal_member_name"));
		normalMember.setNormal_member_birth(request.getParameter("normal_member_birth1")+"-"+request.getParameter("normal_member_birth2")+"-"+request.getParameter("normal_member_birth3"));
		normalMember.setNormal_member_phone(request.getParameter("normal_member_phone1")+"-"+request.getParameter("normal_member_phone2")+"-"+request.getParameter("normal_member_phone3"));
		normalMember.setNormal_member_email(request.getParameter("normal_member_email1")+"@"+request.getParameter("normal_member_email2"));
		normalMember.setNormal_member_gender(request.getParameter("normal_member_gender"));

		JoinMembership_NormalProService joinMembership_NormalProService = new JoinMembership_NormalProService();
		boolean isJoinMemberShipSuccess = joinMembership_NormalProService.joinMemberShip(normalMember);
		
		if (!isJoinMemberShipSuccess) {
			response.setContentType("text/html;charset=UTF-8");
			PrintWriter out = response.getWriter();
			out.println("<script>");
			out.println("alert('회원가입에 실패하였습니다.');");
			out.println("history.back()");
			out.println("</script>");
		} else {
			forward = new ActionForward("joinMemberShipSuccess.page", false);
		}
		return forward;
	}

}
