package action.login;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import action.Action;
import svc.login.JoinMembership_ComgrpProService;
import vo.ActionForward;
import vo.login.CompanyGroupMemberBean;

public class JoinMemberShip_ComgrpProAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = null;
		
		CompanyGroupMemberBean companyGroupMember = new CompanyGroupMemberBean();

		companyGroupMember.setComgrp_member_id(request.getParameter("comgrp_member_id"));
		companyGroupMember.setComgrp_member_pw(request.getParameter("comgrp_member_pw"));
		companyGroupMember.setComgrp_member_name(request.getParameter("comgrp_member_name"));
		companyGroupMember.setComgrp_manager_name(request.getParameter("comgrp_manager_name"));
		companyGroupMember.setComgrp_member_companyno(request.getParameter("comgrp_member_companyno1")+"-"+request.getParameter("comgrp_member_companyno2")+"-"+request.getParameter("comgrp_member_companyno3"));
		companyGroupMember.setComgrp_manager_phone(request.getParameter("comgrp_manager_phone1")+"-"+request.getParameter("comgrp_manager_phone2")+"-"+request.getParameter("comgrp_manager_phone3"));
		companyGroupMember.setComgrp_member_email(request.getParameter("comgrp_member_email1")+"@"+request.getParameter("comgrp_member_email2"));
		companyGroupMember.setComgrp_member_category(request.getParameter("comgrp_member_category"));
		
		JoinMembership_ComgrpProService joinMembership_NormalProService = new JoinMembership_ComgrpProService();
		boolean isJoinMemberShipSuccess = joinMembership_NormalProService.joinMemberShip(companyGroupMember);
		
		if (!isJoinMemberShipSuccess) {
			response.setContentType("text/html;charset=UTF-8");
			PrintWriter out = response.getWriter();
			out.println("<script>");
			out.println("alert('회원가입에 실패하였습니다.');");
			out.println("history.back()");
			out.println("</script>");
		} else {
			forward = new ActionForward("joinMemberShipSuccess.page", false);
		}
		return forward;
	}

}
