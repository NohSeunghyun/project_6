package action.campaign;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import action.Action;
import svc.campaign.GrantSendService;
import vo.ActionForward;

public class GrantSendProAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = null;
		
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		
		long balance = Long.parseLong(request.getParameter("balance"));
		long amount = 0;
		try {
			amount = Long.parseLong(request.getParameter("amount"));
		} catch (Exception e) {
			out.println("<script>");
			out.println("alert('숫자로만 입력해 주세요');");			
			out.println("history.back();");
			out.println("</script>");
		}
		int campaign_no = Integer.parseInt(request.getParameter("campaign_no"));
		int group_no = Integer.parseInt(request.getParameter("group_no"));
		
		if (balance < amount) {
			out.println("<script>");
			out.println("alert('잔액이 부족합니다.\\n잔액보다 적은 금액을 입력해 주세요.');");			
			out.println("history.back();");
			out.println("</script>");
		} else {
			GrantSendService grantSendService = new GrantSendService();
			boolean isCampaignInfoUpdateSuccess = grantSendService.grantSendCampaignInfoUpdate(campaign_no, amount);
			
			if (!isCampaignInfoUpdateSuccess) {
				out.println("<script>");
				out.println("alert('지원금 전송에 실패하였습니다.');");
				out.println("window.opener='Self';");
				out.println("window.open('','_parent','');");
				out.println("window.close();");
				out.println("</script>");
			} else {
				boolean isSupportGroupInfoUpdateSuccess = grantSendService.grantSendSupportGroupInfoUpdate(group_no, amount);
				
				if (!isSupportGroupInfoUpdateSuccess) {
					out.println("<script>");
					out.println("alert('지원금 전송에 실패하였습니다.');");
					out.println("window.opener='Self';");
					out.println("window.open('','_parent','');");
					out.println("window.close();");
					out.println("</script>");
				} else {
					forward = new ActionForward("grantSendSuccess.page", false);
				}
			}
		}
		
		return forward;
	}

}
