package action.campaign;

import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import action.Action;
import svc.campaign.CampaignUpdateService;
import vo.ActionForward;
import vo.campaign.CampaignBean;

public class CampaignChangeImageProAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = null;
		
		ServletContext context = request.getServletContext();
		String uploadPath = context.getRealPath("/images");
		
		int size = 10*1024*1024;
		
		MultipartRequest multi = new MultipartRequest(request, uploadPath, size, "UTF-8", new DefaultFileRenamePolicy());
		
		CampaignBean campaignBean = new CampaignBean();
		
		campaignBean.setCampaign_file(multi.getFilesystemName(((String)multi.getFileNames().nextElement())));
		campaignBean.setCampaign_no(Integer.parseInt(multi.getParameter("campaign_no")));
		
		CampaignUpdateService campaignUpdateService = new CampaignUpdateService();
		boolean isCampaignUpdateSuccess = campaignUpdateService.campaignUpdateChangeImage(campaignBean);
		
		if (!isCampaignUpdateSuccess) {
			response.setContentType("text/html;charset=utf-8");
			PrintWriter out = response.getWriter();
			out.println("<script>");
			out.println("alert('캠페인 수정에 실패하였습니다.');");
			out.println("window.opener='Self';");
			out.println("window.open('','_parent','');");
			out.println("window.close();");
			out.println("</script>");
		} else {
			forward = new ActionForward("campaignUpdateSuccess.page", false);
		}
		return forward;
	}

}
