package action.campaign;

import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import action.Action;
import svc.campaign.CampaignInsertService;
import vo.ActionForward;
import vo.campaign.CampaignBean;

public class CampaignInsertProAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = null;
		
		ServletContext context = request.getServletContext();
		String uploadPath = context.getRealPath("/images");
		
		int size = 10*1024*1024;
		
		MultipartRequest multi = new MultipartRequest(request, uploadPath, size, "UTF-8", new DefaultFileRenamePolicy());
		
		CampaignBean campaignBean = new CampaignBean();
		
		campaignBean.setCampaign_name(multi.getParameter("campaign_name"));
		campaignBean.setCampaign_content(multi.getParameter("campaign_content"));
		campaignBean.setCampaign_file(multi.getFilesystemName(((String)multi.getFileNames().nextElement())));
		
		CampaignInsertService campaignInsertService = new CampaignInsertService();
		boolean isCampaignInsertSuccess = campaignInsertService.campaignInsert(campaignBean);
		
		if (!isCampaignInsertSuccess) {
			response.setContentType("text/html;charset=utf-8");
			PrintWriter out = response.getWriter();
			out.println("<script>");
			out.println("alert('캠페인 등록에 실패하였습니다.');");
			out.println("window.opener='Self';");
			out.println("window.open('','_parent','');");
			out.println("window.close();");
			out.println("</script>");
		} else {
			forward = new ActionForward("campaignInsertSuccess.page", false);
		}
		return forward;
	}

}
