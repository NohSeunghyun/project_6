package action.campaign;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import action.Action;
import svc.admin.AdminGradeChkService;
import svc.campaign.CampaignGetBalanceService;
import vo.ActionForward;

public class GrantSendAdminGradeChkProAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = null;
		
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		
		HttpSession session = request.getSession();
		String admin_id = (String)session.getAttribute("id");
		
		int campaign_no = Integer.parseInt(request.getParameter("campaign_no"));
		String group_no = request.getParameter("group_no");
		String group_name = request.getParameter("group_name");
		
		AdminGradeChkService adminGradeChkService = new AdminGradeChkService();
		String admin_grade = adminGradeChkService.isAdminGrade(admin_id);
		
		if (!admin_grade.equalsIgnoreCase("A")) {
			out.println("<script>");
			out.println("alert('지원금을 전송할 권한이 없습니다.\\nA등급만 지원금 전송 가능합니다.');");
			out.println("window.opener='Self';");
			out.println("window.open('','_parent','');");
			out.println("window.close();");
			out.println("</script>");
		} else {
			CampaignGetBalanceService campaignGetBalanceService = new CampaignGetBalanceService();
			long balance = campaignGetBalanceService.getBalance(campaign_no);
			
			if (balance <= 0) {
				out.println("<script>");
				out.println("alert('전송할 후원금 잔액이 부족합니다.');");
				out.println("window.opener='Self';");
				out.println("window.open('','_parent','');");
				out.println("window.close();");
				out.println("</script>");
			} else {
				String balanceFormat = campaignGetBalanceService.getBalanceFormat(campaign_no);
				request.setAttribute("balanceFormat", balanceFormat);
				request.setAttribute("balance", Long.toString(balance));
				request.setAttribute("campaign_no", Integer.toString(campaign_no));
				request.setAttribute("group_no", group_no);
				request.setAttribute("group_name", group_name);
				
				forward = new ActionForward("grantSendForm.page", false);
			}
		}
		return forward;
	}

}
