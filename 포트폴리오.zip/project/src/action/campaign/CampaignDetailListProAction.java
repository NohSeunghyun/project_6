package action.campaign;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import action.Action;
import svc.admin.AdminGradeChkService;
import svc.campaign.CampaignListService;
import vo.ActionForward;
import vo.campaign.CampaignListBean;

public class CampaignDetailListProAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = null;
		
		int campaign_no = Integer.parseInt(request.getParameter("campaign_no"));
		
		CampaignListService campaignDetailListService = new CampaignListService();
		ArrayList<CampaignListBean> campaignDetailList = campaignDetailListService.getCampaignDetailList(campaign_no);
		
		request.setAttribute("campaignDetailList", campaignDetailList);
		request.setAttribute("campaign_no", Integer.toString(campaign_no));
		
		HttpSession session = request.getSession();
		String admin_id = (String)session.getAttribute("id");
		
		if (admin_id != null) {
			AdminGradeChkService adminGradeChkService = new AdminGradeChkService();
			String admin_grade = adminGradeChkService.isAdminGrade(admin_id);
			if (admin_grade != "") {
				forward = new ActionForward("adminCampaignDetailList.page", false);
			} else {
				forward = new ActionForward("memberCampaignDetailList.page", false);
			}
		} else {
			forward = new ActionForward("campaignDetailList.page", false);
		}
		return forward;
	}

}
